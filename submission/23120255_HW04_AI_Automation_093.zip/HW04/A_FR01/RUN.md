# A_FR01 – nhật ký lượt chạy

| Lượt | Thời điểm (Run by) | Spec @ commit | Report | Kết quả |
|---|---|---|---|---|
| Lượt thử 1 – chrome | 2026-11-17T00:25:37+07:00 | `9a5e558` (bản AI bước 3) | `HW04/reports/chrome_20261117T002537/` | 1 Fail (TC-FR01-01) + 14 did not run |
| Lượt thử 1 – edge | 2026-11-17T00:26:42+07:00 | `9a5e558` | `HW04/reports/edge_20261117T002642/` | 1 Fail (TC-FR01-01) + 14 did not run |
| Lượt thử 1 – firefox | 2026-11-17T00:27:39+07:00 | `9a5e558` | `HW04/reports/firefox_20261117T002739/` | 1 Fail (TC-FR01-01) + 14 did not run |

| Lượt thử 2 – chrome | 2026-11-17T00:31:49+07:00 | `6fc76b5` (5/6a) | `HW04/reports/chrome_20261117T003149/` | 8 Fail, 7 Pass |
| Lượt thử 2 – edge | 2026-11-17T00:34:25+07:00 | `6fc76b5` | `HW04/reports/edge_20261117T003425/` | 8 Fail, 7 Pass |
| Lượt thử 2 – firefox | 2026-11-17T00:37:11+07:00 | `6fc76b5` | `HW04/reports/firefox_20261117T003711/` | 8 Fail, 7 Pass |
| Lượt thử 2 – chrome (chạy lại) | 2026-11-17T00:45:04+07:00 | `6fc76b5` | `HW04/reports/chrome_20261117T004504/` | 8 Fail, 7 Pass |
| Lượt thử 3 – chrome | 2026-11-17T01:01:15+07:00 | `3d19917` (5/6d) | `HW04/reports/chrome_20261117T010115/` | 8 Fail, 7 Pass |
| Lượt thử 3 – edge | 2026-11-17T01:04:19+07:00 | `3d19917` | `HW04/reports/edge_20261117T010419/` | 8 Fail, 7 Pass |
| Lượt thử 3 – firefox | 2026-11-17T01:07:08+07:00 | `3d19917` | `HW04/reports/firefox_20261117T010708/` | 8 Fail, 7 Pass |
| Lượt thử 4 – chrome | 2026-11-17T01:17:31+07:00 | spec `3d19917`, config `597bda7` (trace off) | `HW04/reports/chrome_20261117T011731/` | 8 Fail, 7 Pass |
| Lượt thử 4 – edge | 2026-11-17T01:20:24+07:00 | như trên | `HW04/reports/edge_20261117T012024/` | 8 Fail, 7 Pass |
| Lượt thử 4 – firefox | 2026-11-17T01:23:54+07:00 | như trên | `HW04/reports/firefox_20261117T012354/` | 8 Fail, 7 Pass |
| **Chính thức – chrome** | 2026-11-17T13:47:09+07:00 | spec `9f26855` (5/6e ảnh sau submit), config `597bda7` | `HW04/reports/chrome_20261117T134709/` | 8 Fail, 7 Pass |
| **Chính thức – edge** | 2026-11-17T13:49:50+07:00 | như trên | `HW04/reports/edge_20261117T134950/` | 8 Fail, 7 Pass |
| **Chính thức – firefox** | 2026-11-17T13:52:30+07:00 | như trên | `HW04/reports/firefox_20261117T135230/` | 8 Fail, 7 Pass |

## Lượt thử 1 – ghi chú

- SV chạy trên máy mình, mỗi trình duyệt một lượt (`npx playwright test A_FR01 --project=<chrome|edge|firefox>`).
- 14 TC "did not run": spec bản AI đặt `test.describe.configure({ mode: 'serial' })` → TC đầu Fail thì Playwright bỏ qua mọi TC còn lại (annotation `serial`). Đây là lỗi của script, không phải kết quả của 14 TC.
- Sửa ở commit `HW04[A-FR01] 5/6a – sửa: bỏ mode serial (1 Fail chặn 14 TC)`. Lượt thử 1 không dùng làm lượt chính thức.

## Lượt thử 2 – ghi chú

- Spec sau 5/6a (bỏ serial), trước các sửa 5/6b–5/6d theo review của SV (`review_sv.md`).
- Cả 4 report: Fail = TC-FR01-01, 02, 64, 68, 74, 77, 202, 211; Pass = 05, 07, 17, 18, 22, 23, 63 (trùng nhau giữa các trình duyệt).
- Không dùng làm lượt chính thức: spec còn đồng bộ submit bằng `Promise.race` + `catch` rỗng và gọi oracle API không chờ POST.

## Lượt thử 3 – ghi chú (trước đây ghi là lượt chính thức)

- Spec @ `3d19917` (sau 5/6b–5/6d). Lượt chạy bắt đầu sau commit này (00:58); mọi TC có annotation `phản hồi` (chỉ có từ 5/6b).
- Kiểm "Run by" (17/11, AI mở `index.html` bằng Chrome): tiêu đề report và tên tab đều là `HW04 EShop – <trình duyệt> – Run by: 23120255 · <ISO>`, metadata `Run by` khớp; ISO có múi giờ +07:00.
- Fail = TC-FR01-01, 02, 64, 68, 74, 77, 202, 211; Pass = 05, 07, 17, 18, 22, 23, 63 — trùng nhau ở 3 trình duyệt. Gộp: `results.md`, `bug_groups.md`.
- Đổi thành lượt thử 3 (Z1=d, 17/11): report có trace, 3 report ≈ 30 MB (zip ≈ 10.6 MB, cả 10 report ≈ 26.8 MB > 20 MB). Tắt trace ở `playwright.config.ts`; SV chạy lại A làm lượt chính thức. `results.md`/`bug_groups.md`/ảnh đã gộp lại từ lượt chính thức (6/6b).

## Lượt thử 4 – ghi chú (trước đây ghi là lượt chính thức)

- Spec @ `3d19917`, `playwright.config.ts` @ `597bda7` (trace off, commit 01:17:19; lượt chrome bắt đầu 01:17:31). Mỗi report ≈ 1.1 MB (index.html + results.json + data/ ảnh, error-context; không có trace).
- Kiểm "Run by" (17/11, AI mở `index.html` bằng Chrome): tiêu đề `HW04 EShop – <trình duyệt> – Run by: 23120255 · <ISO +07:00>` ở cả 3 report.
- Fail = TC-FR01-01, 02, 64, 68, 74, 77, 202, 211; Pass = 05, 07, 17, 18, 22, 23, 63 — trùng nhau ở 3 trình duyệt và trùng lượt thử 2, 3.
- Gộp (bước 6, 6/6b): `results.md`, `bug_groups.md` (3 nhóm), `evidence/` 24 ảnh — từ 3 report này.
- Đổi thành lượt thử 4 (lệnh #12, P1=a): thêm ảnh ngay sau khi bấm Đăng Ký (`<TC>_after-submit`, commit `HW04[A-FR01] 5/6e – ảnh sau submit`) → spec đổi sau lượt này. SV chạy lại A làm lượt chính thức; `results.md`/`bug_groups.md`/`evidence/` đã gộp lại từ lượt chính thức (6/6c).

## Lượt chính thức – ghi chú

- Spec @ `9f26855`, config @ `597bda7` (trace off). Mỗi report ≈ 1.9 MB (thêm ảnh `<TC>_after-submit` cho cả 15 TC).
- `Run by` trong `results.json` cả 3: `23120255 · <ISO +07:00>` (khớp cột Bắt đầu).
- Fail = TC-FR01-01, 02, 64, 68, 74, 77, 202, 211; Pass = 05, 07, 17, 18, 22, 23, 63 — trùng ở 3 trình duyệt, trùng lượt thử 2–4.
- Gộp (bước 6, 6/6c): `results.md`, `bug_groups.md` (3 nhóm G1/G2/G3 như cũ), `evidence/` 48 ảnh = 24 ảnh lúc kết thúc + 24 ảnh `<TC>_after-submit_<trình duyệt>` (chỉ TC Fail). `merge_reports.py` mở rộng để tách ảnh `*_after-*`.
- Lượt 13:46:05–07 (3 thư mục `*_20261117T13460x`, 0 test): global-setup báo backend không trả lời → không chạy test; không dùng, không commit.

## Lượt không chính thức 17/11 tối (sự cố Firefox bị Windows Code Integrity chặn)

Kết quả chính thức của A **giữ nguyên** lượt 13:47–13:52 ở bảng trên. Ba lượt dưới đây là **không chính thức**; report **không commit** (chỉ ghi đường dẫn, thư mục để ngoài git).

| Lượt (không chính thức) | Thời điểm (Run by) | Report (không commit) | Kết quả |
|---|---|---|---|
| (1) Gộp chrome + edge + firefox | 2026-11-17T22:56:09+07:00 (SV ghi lượt 23:03; phần firefox bắt đầu 23:01:14 theo `startTime` trong `results.json`) | `HW04/reports/chrome+edge+firefox_20261117T225609/` | chrome 7 Pass / 8 Fail; edge 7 Pass / 8 Fail; firefox 0 / 15 (15 Fail, lỗi `spawn UNKNOWN` khi mở trình duyệt) |
| (2) Firefox riêng, ngay sau (1) | 2026-11-17T23:05:15+07:00 | `HW04/reports/firefox_20261117T230515/` | 0 / 15 (15 Fail, `spawn UNKNOWN`) |
| (3) Firefox riêng, sau khi khởi động lại máy | 2026-11-17T23:22:25+07:00 | `HW04/reports/firefox_20261117T232225/` | 7 Pass / 8 Fail – khớp lượt chính thức firefox 13:52 |

- Nguyên nhân lượt (1), (2): Windows Code Integrity chặn `node.exe` nạp `C:\Users\…\AppData\Local\ms-playwright\firefox-1572\firefox\firefox.exe` ("did not meet the Enterprise signing level requirements or violated code integrity policy"), sự kiện mã **3077** và **3033** lúc **23:05** (log Microsoft-Windows-CodeIntegrity/Operational do SV xuất: `HW04/env/firefox_blocked_20261117.txt`, chép nguyên văn).
- Firefox Fail ở (1), (2) là lỗi môi trường (trình duyệt không khởi động được, không có assertion nào chạy) → không phải Fail của TC, không lập bug.
- Sau khi khởi động lại máy, Firefox chạy được (lượt 3), kết quả trùng lượt chính thức.

## Lượt quay video Task 2 (không chính thức)

Ba lượt dưới đây chạy khi quay video Task 2 (https://youtu.be/TNy_QPFwyB4) – **không chính thức**; report **không commit** (chỉ ghi đường dẫn). Kết quả chính thức giữ lượt 13:47–13:52.

| Lượt (không chính thức) | Thời điểm (Run by) | Report (không commit) | Kết quả |
|---|---|---|---|
| Quay video – chrome | 2026-11-17T23:42:59+07:00 | `HW04/reports/chrome_20261117T234259/` | 7 Pass / 8 Fail |
| Quay video – edge | 2026-11-17T23:45:46+07:00 | `HW04/reports/edge_20261117T234546/` | 7 Pass / 8 Fail |
| Quay video – firefox | 2026-11-17T23:48:34+07:00 | `HW04/reports/firefox_20261117T234834/` | 7 Pass / 8 Fail |
