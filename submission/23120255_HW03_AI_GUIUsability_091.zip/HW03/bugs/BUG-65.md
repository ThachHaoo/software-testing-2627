# BUG-65

- **ID:** BUG-65
- **Tiêu đề:** [Đăng nhập, Hồ sơ] Bấm vào nhãn không focus vào ô nhập tương ứng
- **Severity:** Low
- **Priority:** Low
- Tiền tố GitHub: [HW03-C2-65]

## Môi trường

- SUT: `ttbhanh/eshop-sut` @ `85af3ba` (chạy từ fork `tkob-team/eshop-sut` @ `de0f48f` = 85af3ba + .gitignore, không đổi mã)
- Máy: Windows 11 Home (Asus Vivobook X1505VA), backend `node server.js` :3000 (CSDL seed lại mỗi lần khởi động), web http://localhost:5173 (frontend-web)
- P1 – Google Chrome 157.0.8103.39 qua Playwright 1.48.2 (tham chiếu, Q1) / Windows 11 · CL-38: lượt `runs/P1_auto_20261109-2236.json`, 22:36 09/11/2026
- P2 – Firefox 131.0 bản build của Playwright 1.48.2 / Windows 11 · CL-38: lượt `runs/P2_auto_20261109-2240.json`, 22:40 09/11/2026
- P3 – Chrome Android 156.0.8078.79 / Android 14, POCO F5 qua Playwright _android · CL-38: lượt `runs/P3_auto_20261109-2244.json`, 22:44 09/11/2026
- Màn hình: CL-38 – Đăng nhập, Hồ sơ
- Chi tiết: `HW03/env/environment.md`, thứ tự lượt chạy ở report §3.5

## Tiền điều kiện

Hệ thống frontend web và backend server đang hoạt động bình thường. Màn hình Hồ sơ (`http://localhost:5173/profile`) yêu cầu đã đăng nhập bằng tài khoản `test@eshop.com` / `Test1234!`.

## Các bước tái hiện

1. Truy cập trang Đăng nhập (`http://localhost:5173/login`).
2. Nhấp chuột vào chữ nhãn "Username" và "Mật khẩu", quan sát xem con trỏ gõ phím có nhảy vào ô nhập tương ứng hay không.
3. Đăng nhập tài khoản `test@eshop.com` / `Test1234!` và truy cập trang Hồ sơ (`http://localhost:5173/profile`).
4. Nhấp chuột lần lượt vào chữ nhãn "Họ Tên", "Số điện thoại", "Địa chỉ giao hàng", quan sát xem con trỏ gõ phím có nhảy vào ô nhập tương ứng hay không.

## Expected (trích căn cứ)

- CL-38 – căn cứ: Checklist Text box – 'Correct label'; WCAG 2.2 SC 1.3.1
- Expected của bug: Nhấp chuột vào chữ của nhãn (ví dụ 'Username', 'Mật khẩu', 'Họ Tên', 'Số điện thoại', 'Địa chỉ giao hàng') thì con trỏ gõ phím (focus) phải tự động nhảy vào ô nhập tương ứng.

## Actual

- Cả P1, P2 và P3:
  - **Tại trang Đăng nhập (/login):** Bấm nhãn "Username" không focus ô nhập Username; bấm nhãn "Mật khẩu" không focus ô nhập Mật khẩu.
  - **Tại trang Hồ sơ (/profile):** Bấm nhãn "Họ Tên" không focus ô nhập Họ Tên; bấm nhãn "Số điện thoại" không focus ô nhập Số điện thoại; bấm nhãn "Địa chỉ giao hàng" không focus ô nhập Địa chỉ giao hàng.

## Bằng chứng

- CL-38 P1 (auto): `../checklist/evidence/auto/P1_CL-38_1.png`
- CL-38 P2 (auto): `../checklist/evidence/auto/P2_CL-38_1.png`
- CL-38 P3 (auto): `../checklist/evidence/auto/P3_CL-38_1.png`

## Item liên quan

- CL-38 – Nhãn gắn với ô nhập (bấm nhãn → focus ô) – Failed: P1, P2, P3
- Nhóm dữ kiện: G-08 trong `HW03/bugs/bug_groups.md` (Bấm nhãn không focus ô nhập (Đăng nhập, Hồ sơ)); kiểm trùng: `HW03/bugs/dup_check.md`

## Yêu cầu

(AI điền từ `bug_groups.md`, SV duyệt)

- **Checklist Text box – 'Correct label'; WCAG 2.2 SC 1.3.1:** Nhãn gắn với ô nhập (bấm nhãn → focus ô) (CL-38)

## Ghi chú cô lập

### Dữ kiện (AI chép)

- Actual nguyên văn CL-38 P1 (auto): `Lỗi: Error: /login: bấm nhãn "Username" không focus ô · Lỗi: Error: /login: bấm nhãn "Mật khẩu" không focus ô · Lỗi: Error: /profile: bấm nhãn "Họ Tên" không focus ô · Lỗi: Error: /profile: bấm nhãn "Số điện thoại" không focus ô · Lỗi: Error: /profile: bấm nhãn "Địa chỉ giao hàng" không focus ô · /login "Username": không focus · /login "Mật khẩu": không focus · /profile "Họ Tên": không focus · /profile "Số điện thoại": không focus · /profile "Địa chỉ giao hàng": không focus`
- Actual nguyên văn CL-38 P2 (auto): `Lỗi: Error: /login: bấm nhãn "Username" không focus ô · Lỗi: Error: /login: bấm nhãn "Mật khẩu" không focus ô · Lỗi: Error: /profile: bấm nhãn "Họ Tên" không focus ô · Lỗi: Error: /profile: bấm nhãn "Số điện thoại" không focus ô · Lỗi: Error: /profile: bấm nhãn "Địa chỉ giao hàng" không focus ô · /login "Username": không focus · /login "Mật khẩu": không focus · /profile "Họ Tên": không focus · /profile "Số điện thoại": không focus · /profile "Địa chỉ giao hàng": không focus`
- Actual nguyên văn CL-38 P3 (auto): `Lỗi: Error: /login: bấm nhãn "Username" không focus ô · Lỗi: Error: /login: bấm nhãn "Mật khẩu" không focus ô · Lỗi: Error: /profile: bấm nhãn "Họ Tên" không focus ô · Lỗi: Error: /profile: bấm nhãn "Số điện thoại" không focus ô · Lỗi: Error: /profile: bấm nhãn "Địa chỉ giao hàng" không focus ô · /login "Username": không focus · /login "Mật khẩu": không focus · /profile "Họ Tên": không focus · /profile "Số điện thoại": không focus · /profile "Địa chỉ giao hàng": không focus`
- Nguồn bước tái hiện CL-38: tiền điều kiện (checklist): – · cách kiểm: auto · test tự động: `HW03/tests/C2.spec.ts:239`

### Nhận định

Nhãn không liên kết với ô nhập làm giảm tiện ích thao tác, gây bất tiện cho người dùng khi nhấp vào nhãn chữ nhưng con trỏ không tự nhảy vào ô nhập liệu (chưa kiểm chứng).

## Link GitHub Issue

https://github.com/tkob-team/eshop-sut/issues/250

---

Mô tả bug do SV viết (AI-01 §11); AI chỉ điền phần dữ kiện (Môi trường, căn cứ, Bằng chứng, Item liên quan, Yêu cầu, Dữ kiện).