# P3 – kết quả chạy tay (Chrome Android (POCO F5, adb reverse))

- Trình duyệt / phiên bản:
- OS / thiết bị:
- Bắt đầu – kết thúc:
- Restart backend lúc:
- Mã đơn (seed_orders.py):

| Item | status | notes | ảnh |
|---|---|---|---|
| CL-01 | | | |
| CL-06 | | | |
| CL-08 | | | |
| CL-09 | | | |
| CL-15 | | | |
| CL-24 | | | |
| CL-52 | | | |
| CL-53 | | | |
| CL-62 | | | |
| CL-63 | | | |
| CL-64 | | | |
| SV-02 | | | |
| SV-04 | | | |

## Ảnh tổng quan Task 3

| Màn | ảnh |
|---|---|
| M1 | |
| M2 | |
| M3 | |
| M4 | |
| M5 | |
